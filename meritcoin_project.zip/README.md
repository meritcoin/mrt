# Merit Coin

**MeritCoin (MERITCOIN)**, Solana blockchain üzerinde oluşturulmuş bir kripto para birimidir. 
MeritCoin; turizm ve seyahat sektörlerinde kullanım için tasarlanmıştır. 

## 📌 Genel Bilgiler

- **Token Adı:** Merit Coin  
- **Sembol:** meritcoin  
- **Mint Adresi:** Hb49Fdb9SuMmDYvfnXqs3x1CV6dnYMDqwAvUXzf3pump  
- **Toplam Arz:** 1,000,000 MERITCOIN  
- **Blockchain:** Solana  
- **Oluşturulduğu Platform:** [Pump.fun](https://pump.fun)

## 🚀 Kullanım Amacı

- Güvenli ve hızlı rezervasyon işlemleri
- Uluslararası seyahat harcamalarında düşük işlem ücreti
- Turizm ortaklıklarında token bazlı sadakat sistemi

## 🧪 CLI Üzerinden Token Yönetimi (Opsiyonel)

Eğer Solana CLI kuruluysa aşağıdaki komutlarla işlemlerinizi yapabilirsiniz:

```bash
# Cüzdan bakiyesi sorgulama
solana balance

# Mint adresini kontrol et
spl-token account Hb49Fdb9SuMmDYvfnXqs3x1CV6dnYMDqwAvUXzf3pump

# Yeni token hesabı oluştur (örnek)
spl-token create-account Hb49Fdb9SuMmDYvfnXqs3x1CV6dnYMDqwAvUXzf3pump

# Transfer (örnek)
spl-token transfer Hb49Fdb9SuMmDYvfnXqs3x1CV6dnYMDqwAvUXzf3pump 10 RECIPIENT_WALLET_ADDRESS
```

## 📄 Lisans

MIT Lisansı altında yayınlanmıştır.